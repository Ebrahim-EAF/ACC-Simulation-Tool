import numpy as np
from Data_Center import data_center


def observability_calc() -> None:
    """
    Compute observability of the current system (A,C) and store the result
    back into the data center.
    """
    if data_center.system is None:
        raise RuntimeError("System matrices are not set in Data_Center.")

    A = data_center.system.A
    C = data_center.system.C

    n = A.shape[0]

    # Build observability matrix:
    # [C; CA; CA^2; ... ; CA^{n-1}]
    obsv_blocks = [C]
    Ak = np.eye(n)
    for _ in range(1, n):
        Ak = Ak @ A
        obsv_blocks.append(C @ Ak)

    obsv_mat = np.vstack(obsv_blocks)
    rank = np.linalg.matrix_rank(obsv_mat, tol=1e-9)

    is_obsv = (rank == n)

    data_center.set_observability(is_obsv=is_obsv, rank=rank)

    print(f"[Obsv] rank = {rank}, n = {n}, observable = {is_obsv}")


if __name__ == "__main__":
    observability_calc()
