"""""
main.py
-------

Orchestrator ("maestro") for the ACC demo project.

It does NOT talk to the browser directly. Instead:

- `acc_server.py` (Flask) receives requests from the GUI.
- Inside `acc_server.py`, we call the functions defined here.
- These functions:
    * read configuration / system matrices from Data_Center
    * call the appropriate calculators
    * return a Python dict summarizing the results
      (which Flask then sends back as JSON to the GUI).
"""

from __future__ import annotations

from typing import Dict, Any

from Data_Center import data_center

# ACC simulation / analysis (you will implement this module)
# For now we assume ACC_Calc exposes a run_acc_simulation() function
try:
    from ACC_Calc import run_acc_simulation  # type: ignore
except ImportError:
    # temporary stub so main.py can run even before ACC_Calc exists
    def run_acc_simulation() -> None:
        print("[ACC_Calc] WARNING: run_acc_simulation() stub called (no real ACC yet).")


# Structural analysis tools
from Controllability_Calc import controllability_calc
from Observability_Calc import observability_calc
from Stability_Calc import stability_calc
from Detectability_Stabilizability_Calc import (
    detectability_stabilizability_calc,
)


# ---------------------------------------------------------------------------
# Helper to package analysis results into a dict
# ---------------------------------------------------------------------------

from typing import Dict, Any
from Data_Center import data_center

def _build_analysis_dict() -> Dict[str, Any]:
    a = data_center.analysis

    eigvals_list = None
    if a.eigvals is not None:
        # Convert eigenvalues to strings so JSON can handle them
        eigvals_list = [str(v) for v in a.eigvals]

    return {
        "is_controllable": a.is_controllable,
        "ctrb_rank": a.ctrb_rank,
        "is_observable": a.is_observable,
        "obsv_rank": a.obsv_rank,
        "is_stable": a.is_stable,
        "eigvals": eigvals_list,
        "is_stabilizable": a.is_stabilizable,
        "is_detectable": a.is_detectable,
    }


# ---------------------------------------------------------------------------
# Public orchestration functions
# ---------------------------------------------------------------------------

import numpy as np

from Data_Center import data_center
from ACC_Calc import run_acc_simulation


def run_acc_workflow():
    """
    Run ACC simulation using current config in DataCenter and
    compute open-loop & closed-loop matrices and structural properties.
    """
    cfg = data_center.config
    if cfg is None:
        raise RuntimeError("No ACC configuration stored in DataCenter.config")

    # --- read tau from config.extra, with default 0.5 s ---
    raw_tau = None
    if cfg.extra is not None:
        raw_tau = cfg.extra.get("tau", None)

    try:
        tau = float(raw_tau)
    except (TypeError, ValueError):
        tau = 0.5

    if not np.isfinite(tau) or tau <= 0.0:
        tau = 0.5

    # --- run simulation ---
    sim = run_acc_simulation(
        lead_behaviour=cfg.lead_behaviour.value,
        set_speed=cfg.set_speed,
        safe_distance_level=cfg.safe_distance_level.value,
        tau=tau,
    )

    t = sim["t"]
    x_ego = sim["x_ego"]
    v_ego = sim["v_ego"]
    x_lead = sim["x_lead"]
    v_lead = sim["v_lead"]
    D_rel = sim["D_rel"]
    D_safe = sim["D_safe"]
    u_ego = sim["u_ego"]
    u_lead = sim["u_lead"]

    # --- store results in DataCenter ---
    data_center.store_results(
        t=t,
        x_ego=x_ego,
        v_ego=v_ego,
        x_lead=x_lead,
        v_lead=v_lead,
        distance_rel=D_rel,
        distance_safe=D_safe,
        u_ego=u_ego,
        u_lead=u_lead,
        tau=tau,
    )

    # ------------------------------------------------------------------
    # Build ego open-loop model: xdot = A x + B u, y = C x + D u
    # ------------------------------------------------------------------
    A = np.array([[0.0, 1.0],
                  [0.0, -1.0 / tau]])
    B = np.array([[0.0],
                  [1.0 / tau]])
    C = np.eye(2)
    D = np.zeros((2, 1))

    data_center.set_system_matrices(A, B, C, D)

    # ------------------------------------------------------------------
    # Structural analysis (controllability, observability, stability)
    # ------------------------------------------------------------------
    # controllability matrix: [B, AB]
    Ctrb = np.column_stack([B, A @ B])
    ctrb_rank = int(np.linalg.matrix_rank(Ctrb))
    is_controllable = (ctrb_rank == A.shape[0])

    # observability matrix (with full-state output this is trivially full rank,
    # but we compute it anyway for consistency)
    Obsv = np.vstack([C,
                      C @ A])
    obsv_rank = int(np.linalg.matrix_rank(Obsv))
    is_observable = (obsv_rank == A.shape[0])

    # eigenvalues of A
    eigvals_A = np.linalg.eigvals(A)
    eigvals_A_real = np.real_if_close(eigvals_A)
    # simple asymptotic stability flag (all real parts < 0)
    is_stable = bool(np.all(np.real(eigvals_A) < 0.0))

    data_center.set_controllability(is_controllable, ctrb_rank)
    data_center.set_observability(is_observable, obsv_rank)
    data_center.set_stability(is_stable, eigvals_A_real)

    # ------------------------------------------------------------------
    # Closed-loop matrices for speed mode and distance mode
    # ------------------------------------------------------------------
    # reuse ACC gains & parameters from ACC_Calc
    from ACC_Calc import K_v, K_d, T_gap_base

    # speed mode: u = K_v (v_set - v_ego) = -[0 Kv] x + Kv r
    K_speed = np.array([[0.0, K_v]])     # (1x2)
    A_cl_speed = A - B @ K_speed
    eig_speed = np.real_if_close(np.linalg.eigvals(A_cl_speed))

    # distance mode: x_d = [D_rel, v_ego]^T, approximate linear model
    # use T_gap from simulation (already adjusted by safe_distance_level)
    T_gap = sim["T_gap"]
    A_cl_dist = np.array([[0.0, -1.0],
                          [K_d / tau, -(1.0 + K_d * T_gap) / tau]])
    eig_dist = np.real_if_close(np.linalg.eigvals(A_cl_dist))

    # store stabilizability/detectability flags in a simple way:
    # here everything is controllable/observable, so they are trivially true.
    data_center.set_stabilizability_detectability(
        is_stabilizable=True,
        is_detectable=True,
    )

    # ------------------------------------------------------------------
    # Build result dict for the API
    # ------------------------------------------------------------------
    analysis = {
        "is_controllable": is_controllable,
        "ctrb_rank": ctrb_rank,
        "is_observable": is_observable,
        "obsv_rank": obsv_rank,
        "is_stable": is_stable,
        "eig_open": [float(v) for v in eigvals_A_real],
        "eig_speed": [float(v) for v in eig_speed],
        "eig_dist": [float(v) for v in eig_dist],
    }

    system = {
        "tau": float(tau),
        "A": A.tolist(),
        "B": B.tolist(),
        "C": C.tolist(),
        "D": D.tolist(),
        "Acl_speed": A_cl_speed.tolist(),
        "Acl_dist": A_cl_dist.tolist(),
    }

    timeseries = {
        "t": t.tolist(),
        "v_ego": v_ego.tolist(),
        "v_lead": v_lead.tolist(),
        "D_rel": D_rel.tolist(),
        "D_safe": D_safe.tolist(),
        "u_ego": u_ego.tolist(),
        "u_lead": u_lead.tolist(),
    }

    result = {
        "mode": "acc",
        "summary": data_center.summary(),
        "system": system,
        "analysis": analysis,
        "timeseries": timeseries,
    }

    return result



def run_custom_structural_workflow() -> Dict[str, Any]:
    """
    Custom system mode workflow.
    """
    if data_center.system is None:
        raise RuntimeError("Custom workflow: system matrices are not set.")

    A = data_center.system.A
    if A.shape[0] != A.shape[1]:
        raise ValueError("Custom workflow: A must be square.")

    # Run the 4 structural tools
    controllability_calc()
    observability_calc()
    stability_calc()
    detectability_stabilizability_calc()

    analysis_dict = _build_analysis_dict()

    return {
      "mode": "custom",
      "analysis": analysis_dict,
    }


# ---------------------------------------------------------------------------
# Optional CLI usage (mostly for debugging)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # NOTE: Running this as a separate script will see a *fresh* Data_Center
    # (different process than acc_server). This block is only for quick
    # debugging where you manually set matrices in code below.
    print("[main] This script is intended to be called from acc_server.py,")
    print("       not usually run directly.")
