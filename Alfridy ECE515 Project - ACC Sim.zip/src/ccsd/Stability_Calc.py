import numpy as np
from Data_Center import data_center


def stability_calc() -> None:
    """
    Check internal stability of the system matrix A (continuous-time).
    """
    if data_center.system is None:
        raise RuntimeError("System matrices are not set in Data_Center.")

    A = data_center.system.A
    eigvals = np.linalg.eigvals(A)

    # Strict Lyapunov stability for LTI (continuous-time):
    # all eigenvalues must have negative real part.
    is_stable = np.all(np.real(eigvals) < 0.0)

    data_center.set_stability(is_stable=is_stable, eigvals=eigvals)

    print(f"[Stability] eigenvalues = {eigvals}")
    print(f"[Stability] asymptotically stable = {is_stable}")


if __name__ == "__main__":
    stability_calc()
