import numpy as np
from Data_Center import data_center


def controllability_calc() -> None:
    """
    Compute controllability of the current system (A,B) and store the result
    back into the data center.
    """
    if data_center.system is None:
        raise RuntimeError("System matrices are not set in Data_Center.")

    A = data_center.system.A
    B = data_center.system.B

    n = A.shape[0]

    # Build controllability matrix: [B, AB, A^2 B, ..., A^{n-1} B]
    ctrb_blocks = [B]
    Ak = np.eye(n)
    for _ in range(1, n):
        Ak = Ak @ A
        ctrb_blocks.append(Ak @ B)

    ctrb_mat = np.hstack(ctrb_blocks)
    rank = np.linalg.matrix_rank(ctrb_mat, tol=1e-9)

    is_ctrb = (rank == n)

    # Store results in data center
    data_center.set_controllability(is_ctrb=is_ctrb, rank=rank)

    # Optional: print for quick debugging
    print(f"[Ctrb] rank = {rank}, n = {n}, controllable = {is_ctrb}")


if __name__ == "__main__":
    controllability_calc()
