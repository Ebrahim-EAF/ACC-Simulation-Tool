import numpy as np

# Simulation settings
Ts = 0.1          # sample time [s]
T_final = 40.0    # simulation horizon [s]

# ACC parameters (base values)
T_gap_base = 1.4
D0_base = 10.0

a_min = -3.0      # [m/s^2]
a_max = 2.0       # [m/s^2]

K_v = 0.5         # speed controller gain
K_d = 0.2         # distance controller gain

# --- ACC mode-switching hysteresis parameters -----------------------------
# margin = D_rel - D_safe  (positive ⇒ above safe distance)
MARGIN_HYST     = 2.0    # [m] extra margin before we allow switching BACK to speed mode
DWELL_BACK_S    = 1.5    # [s] how long margin must stay "good" before switching back

# ---------------------------------------------------------------------------
# Lead-vehicle acceleration profiles
# ---------------------------------------------------------------------------

def lead_accel_sine(t: float) -> float:
    return 0.5 * np.sin(0.1 * t)


def lead_accel_sawtooth(t: float, period: float = 20.0, amp: float = 0.5) -> float:
    t_mod = np.mod(t, period)
    ramp = 2.0 * (t_mod / period) - 1.0  # in [-1, 1]
    return amp * ramp


def lead_accel_step(t: float) -> float:
    return 0.5 if t >= 10.0 else 0.0


def get_lead_accel_func(mode: str):
    mode = mode.lower()
    if mode == "sine":
        return lead_accel_sine
    elif mode == "sawtooth":
        return lead_accel_sawtooth
    elif mode == "step":
        return lead_accel_step
    else:
        return lead_accel_sine


# ---------------------------------------------------------------------------
# Main ACC simulation
# ---------------------------------------------------------------------------

def run_acc_simulation(
    lead_behaviour: str,
    set_speed: float,
    safe_distance_level: str,
    tau: float,
):
    """
    Simulate lead + ego vehicles with ACC.

    Parameters
    ----------
    lead_behaviour : {"sine", "sawtooth", "step"}
    set_speed : float
        Desired ego speed [m/s].
    safe_distance_level : {"short", "normal", "long"}
        Determines D0 and T_gap.
    tau : float
        Actuator / vehicle time constant [s].

    Returns
    -------
    dict of numpy arrays:
        t, x_ego, v_ego, x_lead, v_lead, D_rel, D_safe, u_ego, u_lead
    """
    # Safety: enforce lower bound on tau
    if tau is None or not np.isfinite(tau) or tau <= 0.0:
        tau = 0.5

    # Safe-distance parameters based on level
    level = safe_distance_level.lower()
    if level == "short":
        D0 = D0_base * 0.7
        T_gap = T_gap_base * 0.7
    elif level == "long":
        D0 = D0_base * 1.3
        T_gap = T_gap_base * 1.3
    else:
        D0 = D0_base
        T_gap = T_gap_base

    # Time array
    t = np.arange(0.0, T_final + Ts, Ts)
    N = len(t)

    # Allocate arrays
    x_ego = np.zeros(N)
    v_ego = np.zeros(N)
    x_lead = np.zeros(N)
    v_lead = np.zeros(N)
    D_rel = np.zeros(N)
    D_safe = np.zeros(N)
    u_ego = np.zeros(N)
    u_lead = np.zeros(N)

    # Initial conditions
    v_ego[0] = set_speed
    v_lead[0] = set_speed + 5.0     # lead starts a bit faster
    D_rel[0] = D0 + 20.0           # some extra headway
    x_lead[0] = 0.0
    x_ego[0] = x_lead[0] - D_rel[0]

    # Lead acceleration function
    f_lead = get_lead_accel_func(lead_behaviour)

    # --- NEW: mode state + dwell timer for hysteresis switching ----------
    mode = "speed"          # start in speed-follow mode
    time_margin_good = 0.0  # how long margin has been safely > 0

    # optional: record mode for debugging / plotting
    mode_hist = np.zeros(N, dtype=int)  # 0 = speed, 1 = distance

    for k in range(N - 1):
        tk = t[k]

        # --- Lead vehicle ---
        a_lead = float(f_lead(tk))
        u_lead[k] = a_lead

        # Integrate lead dynamics: first-order lag in velocity
        v_lead[k+1] = v_lead[k] + Ts * ( -v_lead[k]/tau + a_lead / tau )
        x_lead[k+1] = x_lead[k] + Ts * v_lead[k]

        # --- Ego vehicle: ACC controller ---
        D_rel[k] = x_lead[k] - x_ego[k]
        D_safe[k] = D0 + T_gap * v_ego[k]

        e_v = set_speed - v_ego[k]
        e_d = D_rel[k] - D_safe[k]

        # -----------------------------------------------------------
        # NEW: hysteresis-based mode switching
        # margin = D_rel - D_safe
        # -----------------------------------------------------------
        margin = e_d  # same as D_rel[k] - D_safe[k]
        dt = Ts  # constant time step

        if mode == "speed":
            # As soon as we violate safe distance → distance mode
            if margin < 0.0:
                mode = "distance"
                time_margin_good = 0.0

        elif mode == "distance":
            if margin > 0.0:
                # we are at/above safe distance → accumulate "good" time
                time_margin_good += dt
                # only switch back if we are comfortably above AND
                # have stayed there for DWELL_BACK_S seconds
                if margin > MARGIN_HYST and time_margin_good >= DWELL_BACK_S:
                    mode = "speed"
                    time_margin_good = 0.0
            else:
                # dropped below safe again → reset timer
                time_margin_good = 0.0

        # record mode for debugging / potential plotting
        mode_hist[k] = 0 if mode == "speed" else 1

        # -----------------------------------------------------------
        # Control law depending on mode
        # -----------------------------------------------------------
        if mode == "speed":
            # speed controller (track set_speed)
            u = K_v * e_v
        else:
            # distance controller (track safe gap)
            u = K_d * e_d

        # Saturation
        u = np.clip(u, a_min, a_max)
        u_ego[k] = u

        # Ego dynamics with first-order lag
        v_ego[k+1] = v_ego[k] + Ts * ( -v_ego[k]/tau + u / tau )
        x_ego[k+1] = x_ego[k] + Ts * v_ego[k]

    # Last sample D_rel / D_safe
    D_rel[-1] = x_lead[-1] - x_ego[-1]
    D_safe[-1] = D0 + T_gap * v_ego[-1]
    u_ego[-1] = u_ego[-2]
    u_lead[-1] = u_lead[-2]

    return dict(
        t=t,
        x_ego=x_ego,
        v_ego=v_ego,
        x_lead=x_lead,
        v_lead=v_lead,
        D_rel=D_rel,
        D_safe=D_safe,
        u_ego=u_ego,
        u_lead=u_lead,
        tau=tau,
        D0=D0,
        T_gap=T_gap,
        mode=mode_hist,  # 0 = speed, 1 = distance

    )
