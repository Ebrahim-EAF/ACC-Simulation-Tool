import numpy as np
from Data_Center import data_center


def detectability_stabilizability_calc() -> None:
    """
    Compute stabilizability (A,B) and detectability (A,C) using PBH-like tests.
    """
    if data_center.system is None:
        raise RuntimeError("System matrices are not set in Data_Center.")

    A = data_center.system.A
    B = data_center.system.B
    C = data_center.system.C

    n = A.shape[0]
    eigvals = np.linalg.eigvals(A)

    # Consider only eigenvalues with Re(lambda) >= 0 (problematic modes)
    problem_modes = [lam for lam in eigvals if np.real(lam) >= -1e-9]

    is_stabilizable = True
    is_detectable = True

    I = np.eye(n)

    for lam in problem_modes:
        # Stabilizability: rank([lam I - A, B]) == n
        mat_stab = np.hstack((lam * I - A, B))
        rank_stab = np.linalg.matrix_rank(mat_stab, tol=1e-9)
        if rank_stab < n:
            is_stabilizable = False

        # Detectability: rank([[lam I - A], [C]]) == n
        mat_det = np.vstack((lam * I - A, C))
        rank_det = np.linalg.matrix_rank(mat_det, tol=1e-9)
        if rank_det < n:
            is_detectable = False

    data_center.set_stabilizability_detectability(
        is_stabilizable=is_stabilizable,
        is_detectable=is_detectable,
    )

    print(f"[Stab/Det] eigvals = {eigvals}")
    print(f"[Stab/Det] stabilizable = {is_stabilizable}, detectable = {is_detectable}")


if __name__ == "__main__":
    detectability_stabilizability_calc()
