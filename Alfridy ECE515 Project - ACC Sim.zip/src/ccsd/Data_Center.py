"""
Data Center module
------------------

This module acts as the central "information hub" for the ACC project.
All user inputs (from the GUI), system matrices, analysis results, and
simulation results are stored here.

This file intentionally contains **no simulation logic** and **no GUI code**.
It only holds data structures and helper methods.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Dict, Any

import numpy as np


# ---------------------------------------------------------------------------
# Enumerations for clean, typed options
# ---------------------------------------------------------------------------

class LeadBehaviour(str, Enum):
    SINE = "sine"
    SAWTOOTH = "sawtooth"
    STEP = "step"          # unit / step-like acceleration


class SafeDistanceLevel(str, Enum):
    CLOSE = "short"        # small time gap
    NORMAL = "normal"      # medium time gap
    FAR = "long"           # large time gap


# ---------------------------------------------------------------------------
# Data classes representing system model and analysis
# ---------------------------------------------------------------------------

@dataclass
class SystemModel:
    """Continuous-time LTI system matrices."""
    A: np.ndarray           # (n x n)
    B: np.ndarray           # (n x m)
    C: np.ndarray           # (p x n)
    D: np.ndarray           # (p x m)


@dataclass
class SystemAnalysis:
    """Stores structural properties of the current system."""
    is_controllable: Optional[bool] = None
    ctrb_rank: Optional[int] = None

    is_observable: Optional[bool] = None
    obsv_rank: Optional[int] = None

    is_stable: Optional[bool] = None
    eigvals: Optional[np.ndarray] = None

    is_stabilizable: Optional[bool] = None
    is_detectable: Optional[bool] = None

    extra: Dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Data classes representing configuration and simulation results
# ---------------------------------------------------------------------------

@dataclass
class SimulationConfig:
    """Stores all user-selected configuration parameters."""
    lead_behaviour: LeadBehaviour
    set_speed: float                   # [m/s]
    safe_distance_level: SafeDistanceLevel

    # Optional: you can add more later (simulation horizon, Ts, etc.)
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SimulationResults:
    """
    Stores the full time histories from one simulation run.
    All arrays are expected to be 1D numpy arrays of the same length.
    """
    t: np.ndarray

    x_ego: np.ndarray
    v_ego: np.ndarray
    x_lead: np.ndarray
    v_lead: np.ndarray

    distance_rel: np.ndarray   # D_rel
    distance_safe: np.ndarray  # D_safe

    u_ego: np.ndarray
    u_lead: np.ndarray

    # You can attach any additional derived metrics here
    metadata: Dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Central DataCenter class (singleton-style)
# ---------------------------------------------------------------------------

class DataCenter:
    """
    Central holder for configuration, system matrices, analysis, and results.

    There is normally a single instance of this class (see `data_center`).
    """

    def __init__(self) -> None:
        # User inputs / scenario
        self.config: Optional[SimulationConfig] = None

        # System matrices A,B,C,D
        self.system: Optional[SystemModel] = None

        # Structural analysis (ctrb/obsv/stability/etc.)
        self.analysis: SystemAnalysis = SystemAnalysis()

        # Time-domain simulation results
        self.results: Optional[SimulationResults] = None

    # ------------- configuration ------------------------------------------

    def set_config(
        self,
        lead_behaviour: LeadBehaviour | str,
        set_speed: float,
        safe_distance_level: SafeDistanceLevel | str,
        **extra: Any,
    ) -> None:
        """
        Store / update the current simulation configuration.
        """
        # Allow calling with raw strings from a web framework
        if isinstance(lead_behaviour, str):
            lead_behaviour = LeadBehaviour(lead_behaviour)
        if isinstance(safe_distance_level, str):
            safe_distance_level = SafeDistanceLevel(safe_distance_level)

        self.config = SimulationConfig(
            lead_behaviour=lead_behaviour,
            set_speed=float(set_speed),
            safe_distance_level=safe_distance_level,
            extra=extra,
        )

    def clear_config(self) -> None:
        """Remove any stored configuration."""
        self.config = None

    # ------------- system matrices ----------------------------------------

    def set_system_matrices(
        self,
        A: np.ndarray,
        B: np.ndarray,
        C: np.ndarray,
        D: np.ndarray,
    ) -> None:
        """Store the LTI system matrices A, B, C, D."""
        self.system = SystemModel(
            A=np.asarray(A, dtype=float),
            B=np.asarray(B, dtype=float),
            C=np.asarray(C, dtype=float),
            D=np.asarray(D, dtype=float),
        )

    # ------------- analysis setters ---------------------------------------

    def set_controllability(self, is_ctrb: bool, rank: int) -> None:
        self.analysis.is_controllable = bool(is_ctrb)
        self.analysis.ctrb_rank = int(rank)

    def set_observability(self, is_obsv: bool, rank: int) -> None:
        self.analysis.is_observable = bool(is_obsv)
        self.analysis.obsv_rank = int(rank)

    def set_stability(self, is_stable: bool, eigvals: np.ndarray) -> None:
        self.analysis.is_stable = bool(is_stable)
        self.analysis.eigvals = np.asarray(eigvals)

    def set_stabilizability_detectability(
        self,
        is_stabilizable: bool,
        is_detectable: bool,
    ) -> None:
        self.analysis.is_stabilizable = bool(is_stabilizable)
        self.analysis.is_detectable = bool(is_detectable)

    # ------------- time-domain results ------------------------------------

    def store_results(
        self,
        t: np.ndarray,
        x_ego: np.ndarray,
        v_ego: np.ndarray,
        x_lead: np.ndarray,
        v_lead: np.ndarray,
        distance_rel: np.ndarray,
        distance_safe: np.ndarray,
        u_ego: np.ndarray,
        u_lead: np.ndarray,
        **metadata: Any,
    ) -> None:
        """
        Store the full time histories from the last simulation run.
        """
        self.results = SimulationResults(
            t=np.asarray(t),
            x_ego=np.asarray(x_ego),
            v_ego=np.asarray(v_ego),
            x_lead=np.asarray(x_lead),
            v_lead=np.asarray(v_lead),
            distance_rel=np.asarray(distance_rel),
            distance_safe=np.asarray(distance_safe),
            u_ego=np.asarray(u_ego),
            u_lead=np.asarray(u_lead),
            metadata=metadata,
        )

    def clear_results(self) -> None:
        """Remove any stored simulation results."""
        self.results = None

    # ------------- convenience / summaries -------------------------------

    def has_config(self) -> bool:
        """Return True if a configuration is currently stored."""
        return self.config is not None

    def has_results(self) -> bool:
        """Return True if simulation results are currently stored."""
        return self.results is not None

    def summary(self) -> Dict[str, Any]:
        """
        Return a lightweight summary that could be sent back to the GUI.
        E.g., final distance, whether safe distance was violated, etc.
        """
        summary: Dict[str, Any] = {}

        if self.config:
            summary["lead_behaviour"] = self.config.lead_behaviour.value
            summary["set_speed"] = self.config.set_speed
            summary["safe_distance_level"] = self.config.safe_distance_level.value

        if self.results:
            res = self.results
            summary["t_final"] = float(res.t[-1])
            summary["min_distance"] = float(np.min(res.distance_rel))
            summary["min_distance_minus_safe"] = float(
                np.min(res.distance_rel - res.distance_safe)
            )
            summary["collision_risk"] = bool(
                np.any(res.distance_rel - res.distance_safe < 0.0)
            )

        if self.system:
            summary["n_states"] = int(self.system.A.shape[0])

        if self.analysis.is_stable is not None:
            summary["is_stable"] = self.analysis.is_stable

        return summary


# ---------------------------------------------------------------------------
# Create a single shared instance for the whole project
# ---------------------------------------------------------------------------

data_center = DataCenter()
