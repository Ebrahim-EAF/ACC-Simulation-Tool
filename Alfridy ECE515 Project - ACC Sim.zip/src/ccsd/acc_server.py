from __future__ import annotations

from flask import Flask, jsonify, request, send_from_directory
import numpy as np

from Data_Center import data_center, LeadBehaviour, SafeDistanceLevel
from main import run_acc_workflow, run_custom_structural_workflow

app = Flask(
    __name__,
    static_folder=".",       # serve Start-GUI.html from current folder
    static_url_path=""
)

# ---------- helpers --------------------------------------------------------

def parse_matrix(text: str) -> np.ndarray:
    """
    Parse a small matrix from a text area.

    Format: rows separated by ';' or newlines,
    entries separated by spaces or commas.

        Example: "0 1; -2 -3"
                 "0, 1\n-2, -3"
    """
    if not text:
        raise ValueError("empty matrix text")

    rows_raw = text.strip().replace("\n", ";").split(";")
    rows = []
    for r in rows_raw:
        r = r.strip()
        if not r:
            continue
        parts = r.replace(",", " ").split()
        row = [float(p) for p in parts]
        rows.append(row)

    if not rows:
        raise ValueError("no rows found")

    # check all rows same length
    ncols = len(rows[0])
    if any(len(r) != ncols for r in rows):
        raise ValueError("rows have different lengths")

    return np.array(rows, dtype=float)


# ---------- routes ---------------------------------------------------------

@app.route("/")
def index():
    # serve the HTML page
    return send_from_directory(".", "Start-GUI.html")


@app.route("/api/config", methods=["POST"])
def api_config():
    """
    Receive configuration (either ACC mode or custom system)
    and store it in the Data Center.
    """
    payload = request.get_json(force=True)

    mode = payload.get("mode", "acc")  # "acc" or "custom"

    if mode == "acc":
        # ----- ACC preset system: just store scenario config ---------------
        lead_behaviour = payload["leadBehaviour"]
        set_speed = float(payload["setSpeed"])
        safe_distance = payload["safeDistance"]

        # NEW: tau may be null / missing → let main.py choose default
        raw_tau = payload.get("tau", None)

        data_center.set_config(
            lead_behaviour=LeadBehaviour(lead_behaviour),
            set_speed=set_speed,
            safe_distance_level=SafeDistanceLevel(safe_distance),
            tau=raw_tau,  # stored inside config.extra["tau"]
        )

        # (later you can also call data_center.set_system_matrices(...) here
        #  for your built-in ego/lead model)

    elif mode == "custom":
        # ----- User provides their own A,B,C,D -----------------------------
        A_txt = payload.get("A", "")
        B_txt = payload.get("B", "")
        C_txt = payload.get("C", "")
        D_txt = payload.get("D", "")

        try:
            A = parse_matrix(A_txt)
            B = parse_matrix(B_txt)
            C = parse_matrix(C_txt)
            D = parse_matrix(D_txt)
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 400

        # store system matrices
        data_center.set_system_matrices(A, B, C, D)

        # also store a dummy "config" describing this mode
        data_center.set_config(
            lead_behaviour=LeadBehaviour.SINE,       # placeholder
            set_speed=0.0,
            safe_distance_level=SafeDistanceLevel.NORMAL,
            mode="custom_system",                     # <--- IMPORTANT
        )

    else:
        return jsonify({"status": "error", "message": "unknown mode"}), 400

    # send back a small summary for debugging
    return jsonify({
        "status": "ok",
        "mode": mode,
        "summary": data_center.summary(),
    })


# -------- NEW: run analysis orchestrated by main.py ------------------------

@app.route("/api/run-analysis", methods=["POST"])
def api_run_analysis():
    """
    Run either the ACC workflow or the custom structural workflow,
    depending on what mode is stored in Data_Center.config.extra["mode"].
    """
    mode = "acc"
    if data_center.config is not None:
        mode = data_center.config.extra.get("mode", "acc")

    if mode == "custom_system":
        # Structural workflow
        result = run_custom_structural_workflow()
    else:
        # ACC workflow
        result = run_acc_workflow()

        # Attach timeseries for plotting (t, v_ego, v_lead, D_rel, D_safe, u_ego)
        res = data_center.results
        if res is not None:
            result["timeseries"] = {
                "t": res.t.tolist(),
                "v_ego": res.v_ego.tolist(),
                "v_lead": res.v_lead.tolist(),
                "D_rel": res.distance_rel.tolist(),
                "D_safe": res.distance_safe.tolist(),
                "u_ego": res.u_ego.tolist(),
            }

    return jsonify({
        "status": "ok",
        "result": result,
    })

# -------- optional: debug summary route -----------------------------------

@app.route("/api/debug-summary")
def api_debug_summary():
    return jsonify(data_center.summary())


# --------------------------------------------------------------------------

if __name__ == "__main__":
    # Run the server, then open http://127.0.0.1:5000 in your browser
    app.run(debug=True)
